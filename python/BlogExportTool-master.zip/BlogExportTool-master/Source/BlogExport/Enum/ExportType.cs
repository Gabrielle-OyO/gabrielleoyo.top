﻿public enum ExportType
{
    NULL = -5,
    CSDN = 0,
}