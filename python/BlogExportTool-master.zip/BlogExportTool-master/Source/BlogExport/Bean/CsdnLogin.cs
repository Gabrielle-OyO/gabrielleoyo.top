﻿public class CsdnLogin
{
    public string loginType { get; set; }
    public string pwdOrVerifyCode { get; set; }
    public string userIdentification { get; set; }
    public string uaToken { get; set; }
    public string webUmidToken { get; set; }
}
