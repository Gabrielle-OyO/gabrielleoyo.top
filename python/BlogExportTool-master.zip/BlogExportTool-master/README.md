# 博客导出工具

# TIPS(2020.1.10) 
里面有个接口（上次更新后没几天就）过期了，没时间修复，项目已开源，请自行修改。

2020.1.15
很迷，CSDN是魔鬼吗，接口一会儿能用，一会儿不能用，今天准备修Bug,发现又可以用了.......

# 更新介绍（2019.9.26）
  1. 新的UI交互界面 
  2. 解决由于文件名导致的无法写文件的问题 
  3. 操作更加简便，可以选择下载，添加鼠标右击菜单 
  4. 以后会集成更多的博客平台  
![](https://img-blog.csdnimg.cn/20190926093033453.png)

# 2019.10.15
解决CSDN反爬虫问题

# 免责声明

 工具免费，请不要用于侵权等各种行为，对于违法使用此工具所造成后果，本工具作者不负任何责任。

 工具免费，请不要用于侵权等各种行为，对于违法使用此工具所造成后果，本工具作者不负任何责任。

 工具免费，请不要用于侵权等各种行为，对于违法使用此工具所造成后果，本工具作者不负任何责任。

 重要事情说三遍

 
# 介绍：

 前段时间使用[Github](https://github.com/)+[Hexo](https://hexo.io)搭建了自己的博客,（顺便加个广告：我的博客：[TonyChenn.github.io](TonyChenn.github.io)），之前一直使用的CSDN写博客，想把CSDN上的博文导出为MarkDown格式的文档，在上传到自己的博客上。在网上找到一些用Python写的工具，经过实验都已不能用。所以在研究了下CSDN的网页结构后， 决定自己动手丰衣足食。  
 ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190926093232463.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTMyODQ3MDY=,size_16,color_FFFFFF,t_70)

 
# 导出效果：

 
## []()![](https://img-blog.csdnimg.cn/20190809084609739.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTMyODQ3MDY=,size_16,color_FFFFFF,t_70)  
 文档内含有**博文标题**，**创建时间**，**Tags**,如下：  
 ![](https://img-blog.csdnimg.cn/20190809084654319.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTMyODQ3MDY=,size_16,color_FFFFFF,t_70)

 
### []()注意

  
  * URL地址输入请按照上面图片中的格式 
  * 运行环境 Win10,如不能使用请[GitHub](https://TonyChenn.cn)联系我 
  * .Net 版本 4.6 
  * CSDN图床中图片部署在hexo上，在电脑中可显示出来，在手机上显示不出来，建议替换图片  
--------
 
### []()使用方法

1. 选择平台
2. 粘贴对应网址
3. 点击解析
4. CSDN下载需要配置UserName和UserToken;(待优化为登陆)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191015094146549.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3UwMTMyODQ3MDY=,size_16,color_FFFFFF,t_70)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191014094037967.png)

--------
 如链接不能使用，或者工具失效，请与我联系。也欢迎提出各种宝贵意见。
