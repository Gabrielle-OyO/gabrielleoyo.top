<?php


class LinksAction
{

}
