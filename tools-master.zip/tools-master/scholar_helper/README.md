## Google Scholar Citation
```
$ pip install pipenv
$ pipenv install --dev
$ pipenv shell
$ pip install requests bs4 lxml
$ python main.py
```