## 起步

悬浮式文章目录树，定在右侧。

## 使用方法

第一步：下载本插件，放在 `usr/plugins/` 目录中；
第二步：激活插件；

## 预览

![20160401112707.png][1]

github开源地址：[https://github.com/hongweipeng/MenuTree_for_typecho][2]

## 与我联系：

作者：hongweipeng
主页：[https://www.hongweipeng.com/][3]
或者通过 Emai: hongweichen8888@sina.com
有任何问题也可评论留言


  [1]: https://www.hongweipeng.com/usr/uploads/2016/04/1824863673.png
  [2]: https://github.com/hongweipeng/MenuTree_for_typecho
  [3]: https://www.hongweipeng.com/