# ContentIndex for Typecho

一个为 Typecho 文章单页生成内容目录的插件。

Blog: http://note.laobubu.net/archives/typecho-contentindex

## 安装

将程序文件夹丢到 `usr/plugins/ContentIndex` 下即可，文件夹自己建。


## 配置

访问后台-插件管理，启用 ContentIndex。


## 一些有用的信息

### 样式

此扩展会在文章内容开头处插入一个 `id="theContentIndex"` 的 div，里面就是导航及链接。

此外还有扩展目录下的 `ContentIndex.css` 会被加入到页面中。

如果你不喜欢目录藏左下角的这种设计，可以自行编辑之。

如果编辑出了很赞的样式，可以去[我博客](http://note.laobubu.net/archives/typecho-contentindex)留言分享哦~