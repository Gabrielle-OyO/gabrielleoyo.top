# [B3logForHacPai](https://dt27.org/php/b3log-hacpai-typecho/)
**黑客派社区实时同步插件 For Typecho**

基于[B3log理念][1]，整合 [Typecho][2] 博客与 [黑客派][3] 社区，实现内容及评论互相实时同步。丰富博客与社区内容。

## Features&Todo 
* [x] 博客发布博文 -> 社区发布帖子
* [x] 博客更新博文 -> 社区更新帖子
* [x] 博客发布评论 -> 社区发布回帖
* [x] 社区发布回帖 -> 博客发布评论

###### Plugin License
> Copyright © 2016 [DT27](https://dt27.org)  
> License: [GNU General Public License v3.0](http://www.gnu.org/licenses/gpl-3.0.html)
 [1]: https://hacpai.com/b3log
 [2]: http://typecho.org/
 [3]: https://hacpai.com/