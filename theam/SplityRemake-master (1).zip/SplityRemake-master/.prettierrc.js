module.exports = {
    bracketSpacing: true,
    jsxBracketSameLine: true,
    singleQuote: false,
    trailingComma: "es5",
    tabWidth: 4,
    printWidth: 240,
};
