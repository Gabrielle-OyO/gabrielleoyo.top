![screenshot.png][1]
## 前言：
捣鼓一个自己的主题，这个想法我想每个博主都有，有这个想法是在我下定决心搭建一个属于自己的博客的时候，那时的我懂的也不是很多，也就了解一点点建站的知识，关于模板开发并未深入了解，然后就一直搁置，搁置好久，中途也尝试过，只因学业繁忙又搁置了，终于等到毕业了，每天无所事事，只好找点事情做做，于是开始了填坑之旅～
由于本人第一次开发模板，也就是此模板是我第一个模板，还存在很多问题，还需时间优化～
另外，如有任何建议和问题，请在issues留言～
感谢！

注意：书单页并未完善，如需更改书本信息，请到源码文件修改

！！！ 请在基本设置-评论设置-关闭反垃圾


ps：为了更好的食用，请务必搭配以下-推荐插件：
#### https://github.com/AlanDecode/Typecho-Plugin-DoubanBoard （豆瓣插件，用于展示影单）
#### https://github.com/MoePlayer/APlayer-Typecho 用于展示歌单）
#### https://github.com/moeshin/QPlayer2-Typecho （悬浮歌单）--为了能跟本主题更好的适配，已跟主题一起打包
#### https://github.com/typecho-fans/plugins/tree/master/Links （友情链接）--为了能跟本主题更好的适配，已跟主题一起打包
特别感谢以上优秀开源者~

欢迎加入博友群：<a href="https://jq.qq.com/?_wv=1027&k=xK9A9ZGL">345494089</a>
## 介绍：
vCards一名取自网上开源的html模板的名字，当时看到这个模板的时候，它本身具有的简约个性便燃起了我开发模板的心，所以就选这套模板进行嵌套typecho模板，这也是我第一次开发模板，还有很多不足。

## 功能：
该模板具备基本博客功能，外加pjax、移动端启动页
基本配色为黑、白、蓝灰
现有的独立页面有：文章归档、动态、友链、留言、关于、书单、相册、影单、日志、语录收藏

后期计划会加入：
短代码样式
文章点赞√
表情包支持√
隐私回复
私密文章等等



## 页面演示：
![网页捕获_16-7-2021_122055_www.rz.sb.jpeg][2]
![网页捕获_16-7-2021_122213_www.rz.sb.jpeg][3]
![网页捕获_16-7-2021_122321_www.rz.sb.jpeg][4]




  [1]: https://cdn.jsdelivr.net/gh/irozhi/irils-imgs/usr/uploads/2021/07/2342695856.png
  [2]: https://cdn.jsdelivr.net/gh/irozhi/irils-imgs/usr/uploads/2021/07/1481835310.jpeg
  [3]: https://cdn.jsdelivr.net/gh/irozhi/irils-imgs/usr/uploads/2021/07/2944046976.jpeg
  [4]: https://cdn.jsdelivr.net/gh/irozhi/irils-imgs/usr/uploads/2021/07/1717459389.jpeg
