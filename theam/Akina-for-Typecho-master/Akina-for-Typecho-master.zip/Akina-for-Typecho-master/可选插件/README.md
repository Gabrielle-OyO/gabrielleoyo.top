# 友情链接插件
据说是修复了一些bug。
# 数学公式插件
MardownKatex是一个原生支持Latex公式的typecho插件。是基于[ParseDown](https://github.com/erusev/parsedown)和[ParseDown-Extra](https://github.com/erusev/parsedown-extra)开发的，Latex渲染使用的是[KaTeX](https://github.com/Khan/KaTeX)的JS库，渲染速度飞快。    
MarkdownKatex-typecho项目地址[https://github.com/zyuzhi/MarkdownKatex-typecho](https://github.com/zyuzhi/MarkdownKatex-typecho)    
注意：本文件夹下的MardownKatex插件修改了资源地址，使用Jsdelivr进行加速。    

2021-08-24: MardownKatex插件 会对md语法解析造成影响。导致文字排版错误，待调整。
