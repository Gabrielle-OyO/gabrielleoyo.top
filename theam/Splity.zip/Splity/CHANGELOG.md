### Splity-Remake

基于Splity主题创建的typecho主题

当前版本（Date：2020-04-11） 0.0.1

Change Log: 

- 修复黑暗模式的bug
- 增加文章目录的输出
- 调整文章缩略图的输出
- 去除主页的走马灯效果
- 去除个人信息栏的简介-- 
    - ~~后续准备添加一言api~~(已完成)
- 调整最新文章的数量
- 文章页自动隐藏 最新文章和最热文章两个项目
- 内置添加图片灯箱效果
- 调整markdown文章格式
- 调整header的栏目输出
- 页首添加了动画
- 修改了文章中a标签的样式
- 修改了图片的显示
- mobile端文章目录的支持
- 修复了图片分享的bug
- 添加了`pretag`和`prebadge`的字段支持

> 徽标和标签支持
> <img src="https://img.tanknee.cn/blogpicbed/2020/04/2020041177f60cc42daeb.png"/>
> 详情请前往文章编辑页查看！

- 修复了tag输出的问题
- 添加颜文字的支持
- 添加了对LaTeX公式的支持
- 修复OwO颜文字的显示
- 修改评论区的字体
- 修复button样式
- 修复生成分享海报时的问题
 - 修复海报图片跨域问题
 - 修复海报摘要显示问题
- 添加index界面文章发表时间的显示
- 添加了评论区UA的显示
- 加回了走马灯效果，并修改了图片显示逻辑
- 修复登录按钮显示异常
- 修复了侧边栏的z-index
- 完善了三图状态下的文章显示
- 完善了poster海报的显示-->现在失败的主要原因还是跨域，这主要跟图片资源服务器有关
- 修复时间显示的问题
- 添加instant-page脚本依赖
- 去除广告图片
- 实现归档页面
- 修复归档页面的显示问题
- 添加图片懒加载
- 添加友链的短代码
    > [link url="here is the link" img="here is the img url" des="here is the description of the link"] here is the name of link[/link]

> <img src="https://img.tanknee.cn/blogpicbed/2020/04/202004217bcc85c4cc1f9.png"/>

- add lazy load placeholder

