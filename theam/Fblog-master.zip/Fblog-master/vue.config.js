module.exports = {
	publicPath: './',
    devServer: {
        port: 4567
    }
}