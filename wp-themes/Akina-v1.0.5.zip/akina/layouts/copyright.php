<?php 

	/**
	 * copyright
	 */

?>

	<div class="open-message">
	<p>声明：<?php bloginfo('name');?>|版权所有，违者必究|如未注明，均为原创|本网站采用<a href="https://creativecommons.org/licenses/by-nc-sa/3.0/" target="_blank">BY-NC-SA</a>协议进行授权</p>
	<p>转载：转载请注明原文链接 - <a href="<?php the_permalink();?>"><?php the_title(); ?></a></p>	
	</div>	
